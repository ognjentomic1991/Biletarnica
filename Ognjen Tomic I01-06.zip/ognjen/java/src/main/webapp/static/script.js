// ognjentomic1991@gmail.com
var podatak_unet = function (podatak){
    var data = podatak.value;
    if(data.length>0){
        podatak.style.border="none";
    }else{
        podatak.style.border = "2px solid red";
    }
    return data.length>0;
}

var duzina_dobra = function (podatak){
    var data = podatak.value;
    if(podatak.length>3 && podatak.length<20){
        podatak.style.border="none";
    }else{
        podatak.style.border = "2px solid red";
    }
    return data.length>3 && data.length<20;
}

var provera_nedozvoljenih_karaktera = function (podatak){
    var format = /[`!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~]/;
    var data = podatak.value;
    if(!format.test(data)){
        podatak.style.border="none";
    }else{
        podatak.style.border = "2px solid red";
    }
    return format.test(data);
}

var sadrzi = function (a,b){
    for(var i=0;i<b.length;i++){
        if(a.includes(b[i])){
            return true;
        }
    }
    return false;
}

var valid_email = function (email){
    var domains = [".rs",".com","edu"];
    return email.includes("@") && (sadrzi(email,domains));
}

var info = function (tekst){
    var poruka = document.getElementById("poruka");
    if(poruka!=null){
        poruka.innerHTML=tekst;
    }
}

var uloguj = document.getElementById("uloguj");
if(uloguj!=null){
    var korime = document.getElementById("korime");
    var lozinka = document.getElementById("lozinka");
    uloguj.addEventListener("click",(e)=>{
        if(!podatak_unet(korime)){
            e.preventDefault();
            info("morate uneti korisnicko ime");
            return;
        }
        if(!podatak_unet(lozinka)){
            e.preventDefault();
            info("morate uneti lozinku");
            return;
        }
        if(!duzina_dobra(korime)){
            e.preventDefault();
            info("duzina unosa mora biti izmedju 3 i 20 karaktera");
            return;
        }
        if(!duzina_dobra(lozinka)){
            e.preventDefault();
            info("duzina unosa mora biti izmedju 3 i 20 karaktera");
            return;
        }
        if(provera_nedozvoljenih_karaktera(korime)){
            e.preventDefault();
            info("detektovani nedozvoljeni karakteri");
            return;
        }
        if(provera_nedozvoljenih_karaktera(lozinka)){
            e.preventDefault();
            info("detektovani nedozvoljeni karakteri");
            return;
        }

    });
}

var registruj = document.getElementById("registruj");
if(registruj!=null){
    var polja=[
        document.getElementById("ime"),
        document.getElementById("prezime"),
        document.getElementById("korime"),
        document.getElementById("lozinka"),
        document.getElementById("potvrda"),
        document.getElementById("email"),
        document.getElementById("adresa"),
        document.getElementById("telefon")
    ]

    registruj.addEventListener("click",(e)=>{
        for(var i=0;i<polja.length;i++){
            if(!podatak_unet(polja[i])){
                e.preventDefault();
                info("morate uneti sve podatke");
                return;
            }
            if(!duzina_dobra(polja[i])){
                e.preventDefault();
                info("duzina unosa mora biti izmedju 3 i 20 karaktera");
                return;
            }
            if(provera_nedozvoljenih_karaktera(polja[i])){
                e.preventDefault();
                info("detektovani nedozvoljeni karakteri");
                return;
            }
            if(!valid_email(document.getElementById("email"))){
                e.preventDefault();
                info("neispravan format email adrese");
                return;
            }
        }
    });
}