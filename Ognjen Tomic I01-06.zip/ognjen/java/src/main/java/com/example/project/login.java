package com.example.project;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet(name = "login", value = "/login")
public class login extends HttpServlet {

    public void init() {

    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        HttpSession session = request.getSession();
        if(session.getAttribute("id") != null){
            request.setAttribute("poruka","vec ste ulogovani");
            response.setContentType("text/html");
            request.getRequestDispatcher("/index.jsp").forward(request, response);
        }

        response.setContentType("text/html");
        request.getRequestDispatcher("/login.jsp").forward(request, response);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        String korime = request.getParameter("korime");
        String lozinka = request.getParameter("lozinka");
        //provera da li susvi podacci uneti
        //provera duzine podataka
        //provera nedozvoljenih karaktera

        korisnik k = korisnik.login(korime,lozinka);
        if(k==null){
            request.setAttribute("poruka","korisnik nije pronadjen");
            doGet(request, response);
            return;
        }else{
            request.setAttribute("poruka","ulogovani ste");
            HttpSession session = request.getSession();
            session.setAttribute("id", k.getId());
            session.setAttribute("korisnik",k);
            doGet(request, response);
            return;
        }
    }

    public void destroy() {
    }
}
