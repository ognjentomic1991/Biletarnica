package com.example.project;

import java.io.*;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

@WebServlet(name = "pretraga", value = "/pretraga")
public class pretraga extends HttpServlet {

    public void init() {

    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
        String pretraga = request.getParameter("search");
        String trazi = request.getParameter("trazi");
        ArrayList<dogadjaj> arr = dogadjaj.pretrazi(trazi,pretraga);

        HttpSession session = request.getSession();

            //neulogovan
            ArrayList<dogadjaj> arr2 = new ArrayList<dogadjaj>();
            if(request.getParameter("pages")!=null){
                int pages = Integer.parseInt(request.getParameter("pages"));
                System.out.println("pages="+pages);
                for(int i=(pages-1)*10;i<Math.min(pages*10+10,arr.size());i++){
                    arr2.add(arr.get(i));
                }
            }else{
                for(int i=0;i<Math.min(10,arr.size());i++){
                    arr2.add(arr.get(i));
                }
            }
            double n = Math.ceil(arr.size()/10)+1;
            System.out.println(n);
            request.setAttribute("pagesnum",n);
            request.setAttribute("dogadjaji",arr2);
            request.getRequestDispatcher("/index.jsp").forward(request, response);
            return;



        //trazi(naziv,pocetak,kraj,mesto)
    }

    public void destroy() {
    }
}

