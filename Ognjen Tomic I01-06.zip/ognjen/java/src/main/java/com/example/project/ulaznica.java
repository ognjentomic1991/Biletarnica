package com.example.project;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class ulaznica {
    private int id;
    private int cena;
    private String kategorija;
    private int broj;
    private int dogadjaj_id;

    public ulaznica(String kategorija,int cena,  int broj, int dogadjaj_id) {
        this.cena = cena;
        this.kategorija = kategorija;
        this.broj = broj;
        this.dogadjaj_id = dogadjaj_id;
    }

    public ulaznica(int dogadjaj_id) {
        this.dogadjaj_id = dogadjaj_id;
    }

    public ulaznica(int id, int cena, String kategorija, int broj) {
        this.id = id;
        this.cena = cena;
        this.kategorija = kategorija;
        this.broj = broj;
    }

    public ulaznica(int id, String kategorija, int cena, int broj, int dogadjaj_id) {
        this.id = id;
        this.cena = cena;
        this.kategorija = kategorija;
        this.broj = broj;
        this.dogadjaj_id=dogadjaj_id;
    }

    public static ulaznica get_by_id(int id){
        ulaznica d = null;
        String sql = "SELECT * FROM ulaznice WHERE id="+id;

        Connection conn = konekcija.konektuj();
        try {
            ResultSet rs = conn.createStatement().executeQuery(sql);
            while (rs.next()){
                d = new ulaznica(
                        rs.getInt("id"),
                        rs.getString("kategorija"),
                        rs.getInt("cena"),
                        rs.getInt("broj"),
                        rs.getInt("dogadjaj_id")
                );

            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            return null;
        }

        return d;
    }

    public static ArrayList<ulaznica> vrati_sve(){
        ArrayList<ulaznica> arr = new ArrayList<>();
        String sql = "SELECT * FROM ulaznice";
        Connection conn = konekcija.konektuj();

        try {
            ResultSet rs = conn.createStatement().executeQuery(sql);
            while (rs.next()){
                arr.add(
                        new ulaznica(
                                rs.getInt("id"),
                                rs.getString("kategorija"),
                                rs.getInt("cena"),
                                rs.getInt("broj"),
                                rs.getInt("dogadjaj_id")
                        )
                );
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            return arr;
        }

        return arr;
    }

    public void dodaj(){
        Connection conn = konekcija.konektuj();
        try {
            Statement st = conn.createStatement();
            String sql = "INSERT INTO ulaznice VALUES(null,'"+this.kategorija+"','"+this.cena+"','"+this.broj+"','"+this.dogadjaj_id+"')";
            st.executeUpdate(sql);
            conn.close();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public static void prodaj(int id){
        Connection conn = konekcija.konektuj();
        try {
            Statement st = conn.createStatement();
            String sql = "UPDATE ulaznice SET broj=broj-1 WHERE id="+id;
            st.executeUpdate(sql);
            conn.close();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCena() {
        return cena;
    }

    public void setCena(int cena) {
        this.cena = cena;
    }

    public String getKategorija() {
        return kategorija;
    }

    public void setKategorija(String kategorija) {
        this.kategorija = kategorija;
    }

    public int getBroj() {
        return broj;
    }

    public void setBroj(int broj) {
        this.broj = broj;
    }

    public int getDogadjaj_id() {
        return dogadjaj_id;
    }

    public void setDogadjaj_id(int dogadjaj_id) {
        this.dogadjaj_id = dogadjaj_id;
    }

    @Override
    public String toString() {
        return "ulaznica{" +
                "id=" + id +
                ", cena=" + cena +
                ", kategorija='" + kategorija + '\'' +
                ", broj=" + broj +
                ", dogadjaj_id=" + dogadjaj_id +
                '}';
    }
}
