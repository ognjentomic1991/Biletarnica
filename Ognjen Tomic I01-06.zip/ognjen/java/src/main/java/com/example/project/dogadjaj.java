package com.example.project;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

public class dogadjaj {
    private int id;
    private String naziv;
    private String pocetak;
    private String vreme;
    private String kraj;
    private String mesto;
    private String opis;

    public dogadjaj(int id, String naziv, String pocetak, String vreme, String kraj, String mesto, String opis) {
        this.id = id;
        this.naziv = naziv;
        this.pocetak = pocetak;
        this.vreme = vreme;
        this.kraj = kraj;
        this.mesto = mesto;
        this.opis = opis;
    }

    public dogadjaj(String naziv, String pocetak, String vreme, String kraj, String mesto, String opis) {
        this.naziv = naziv;
        this.pocetak = pocetak;
        this.vreme = vreme;
        this.kraj = kraj;
        this.mesto = mesto;
        this.opis = opis;
    }

    public boolean proslo() throws ParseException {
        Date krajj = new SimpleDateFormat("yyyy-MM-dd").parse(this.kraj);
        Date trenutni = new Date();

        System.out.println(this.kraj+"="+krajj+"<"+trenutni);

        if (krajj.before(trenutni)) {
            return true;
        }
        return false;
    }

    public static dogadjaj get_by_id(int id){
        dogadjaj d = null;
        String sql = "SELECT * FROM dogadjaji WHERE id="+id;

        Connection conn = konekcija.konektuj();
        try {
            ResultSet rs = conn.createStatement().executeQuery(sql);
            while (rs.next()){
                d = new dogadjaj(
                                rs.getInt("id"),
                                rs.getString("naziv"),
                                rs.getString("pocetak_datum"),
                                rs.getString("vreme_pocetak"),
                                rs.getString("kraj_datum"),
                                rs.getString("mesto"),
                                rs.getString("opis")
                        );

            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            return null;
        }

        return d;
    }

    public static void prodaj(int id){
        Connection conn = konekcija.konektuj();
        try {
            Statement st = conn.createStatement();
            String sql = "UPDATE dogadjaji SET broj=broj-1 WHERE id="+id;
            st.executeUpdate(sql);
            conn.close();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public static void promeniNaziv(String x,int id,String pocetak,String kraj){
        Connection conn = konekcija.konektuj();
        try {
            Statement st = conn.createStatement();
            String sql = "UPDATE dogadjaji SET naziv='"+x+"',pocetak_datum='"+pocetak+"',kraj_datum='"+kraj+"' WHERE id="+id;
            st.executeUpdate(sql);
            conn.close();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public void dodaj(){
        Connection conn = konekcija.konektuj();
        try {
            Statement st = conn.createStatement();
            String sql = "INSERT INTO dogadjaji VALUES(null,'"+this.opis+"','"+this.pocetak+"','"+this.vreme+"','"+this.kraj+"','"+this.mesto+"','"+this.opis+"')";
            st.executeUpdate(sql);
            conn.close();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public static ArrayList<dogadjaj> pretrazi(String trazi, String pretraga){
        ArrayList<dogadjaj> arr = new ArrayList<>();
        String sql = "SELECT * FROM dogadjaji";
        if(trazi.equals("naziv")){
            sql = "SELECT * FROM dogadjaji WHERE naziv LIKE '%"+pretraga+"%'";
        }
        if(trazi.equals("pocetak")){
            sql = "SELECT * FROM dogadjaji WHERE pocetak_datum > '"+pretraga+"'";
        }
        if(trazi.equals("kraj")){
            sql = "SELECT * FROM dogadjaji WHERE kraj_datum < '"+pretraga+"'";
        }
        if(trazi.equals("mesto")){
            sql = "SELECT * FROM dogadjaji WHERE mesto LIKE '%"+pretraga+"% AND kraj_datum<GETDATE()'";
        }

        Connection conn = konekcija.konektuj();
        try {
            ResultSet rs = conn.createStatement().executeQuery(sql);
            while (rs.next()){
                arr.add(
                        new dogadjaj(
                                rs.getInt("id"),
                                rs.getString("naziv"),
                                rs.getString("pocetak_datum"),
                                rs.getString("vreme_pocetak"),
                                rs.getString("kraj_datum"),
                                rs.getString("mesto"),
                                rs.getString("opis")
                        )
                );
            }
            System.out.println(arr.size());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            return arr;
        }

        return arr;
    }

    public ArrayList<ulaznica> get_ulaznice(){
        ArrayList<ulaznica> arr = new ArrayList<>();

        String sql = "SELECT * FROM ulaznice WHERE dogadjaj_id="+this.id;
        Connection conn = konekcija.konektuj();
        try {
            ResultSet rs = conn.createStatement().executeQuery(sql);
            while (rs.next()){
                arr.add(
                        new ulaznica(
                                rs.getInt("id"),
                                rs.getString("kategorija"),
                                rs.getInt("cena"),
                                rs.getInt("broj"),
                                rs.getInt("dogadjaj_id")
                        )
                );
            }
            System.out.println(arr.size());
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            return arr;
        }

        return arr;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNaziv() {
        return naziv;
    }

    public void setNaziv(String naziv) {
        this.naziv = naziv;
    }

    public String getPocetak() {
        return pocetak;
    }

    public void setPocetak(String pocetak) {
        this.pocetak = pocetak;
    }

    public String getVreme() {
        return vreme;
    }

    public void setVreme(String vreme) {
        this.vreme = vreme;
    }

    public String getKraj() {
        return kraj;
    }

    public void setKraj(String kraj) {
        this.kraj = kraj;
    }

    public String getMesto() {
        return mesto;
    }

    public void setMesto(String mesto) {
        this.mesto = mesto;
    }

    public String getOpis() {
        return opis;
    }

    public void setOpis(String opis) {
        this.opis = opis;
    }

    @Override
    public String toString() {
        return "dogadjaj{" +
                "id=" + id +
                ", naziv='" + naziv + '\'' +
                ", pocetak='" + pocetak + '\'' +
                ", vreme='" + vreme + '\'' +
                ", kraj='" + kraj + '\'' +
                ", mesto='" + mesto + '\'' +
                ", opis='" + opis + '\'' +
                '}';
    }
}
