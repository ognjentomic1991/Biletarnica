package com.example.project;

import java.io.*;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

@WebServlet(name = "blagajnik", value = "/blagajnik")
public class blagajnik extends HttpServlet {

    public void init() {

    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        HttpSession session = request.getSession();
        if(session.getAttribute("id") == null){
            request.setAttribute("poruka","niste ulogovani");
            response.setContentType("text/html");
            request.getRequestDispatcher("/index.jsp").forward(request, response);
        }else{
            korisnik k = (korisnik) session.getAttribute("korisnik");
            if(k.getStatus().equals("blagajnik")){
                request.setAttribute("blagajnik",k);
                request.setAttribute("korisnici",korisnik.vrati_korisnike());
                response.setContentType("text/html");
                ArrayList<dogadjaj> arr = dogadjaj.pretrazi("","");
                request.setAttribute("dogadjaji",arr);

                //prodaja ulaznica
                //id_ulaznica,(id_korisnik)
                //korisnik,ulaznica,dogadjaj
                ArrayList<ulaznica> ull = ulaznica.vrati_sve();
                request.setAttribute("ulaznice",ull);

                ArrayList<rezervacija> as = rezervacija.getRezervisane();
                request.setAttribute("rezervisane",as);

                request.getRequestDispatcher("/blagajnik.jsp").forward(request, response);
            }else{
                request.setAttribute("poruka","samo blagajnik ima pristup ovoj stranici");
                response.setContentType("text/html");
                request.getRequestDispatcher("/index.jsp").forward(request, response);
            }
        }

    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        //prodajRezervisanu,id_rezervacije,blokiraj
        if(request.getParameter("prodajRezervisanu")!=null){
            int id_rezervacije = Integer.parseInt(request.getParameter("id_rezervacije"));
            new rezervacija(id_rezervacije).blokiraj();
            response.sendRedirect("http://localhost:8080/project_war/blagajnik");
            return;
        }

        //prodajRezervisanu,id_rezervacije
        if(request.getParameter("prodajRezervisanu")!=null){
            int id_rezervacije = Integer.parseInt(request.getParameter("id_rezervacije"));
            new rezervacija(id_rezervacije).prodaj();
            response.sendRedirect("http://localhost:8080/project_war/blagajnik");
            return;
        }

        String prodaj1 = request.getParameter("prodaj1");
        if(prodaj1!=null){
            int id = Integer.parseInt(request.getParameter("id"));
            ulaznica.prodaj(id);
            response.sendRedirect("http://localhost:8080/project_war/blagajnik");
            return;
        }


        //promeniNaziv,id,nazivDogadjaj, pocetak_vreme kraj_vreme
        String promeniNaziv = request.getParameter("promeniNaziv");
        String pocetak_vreme = request.getParameter("pocetak_vreme");
        String kraj_vreme = request.getParameter("kraj_vreme");
        if(promeniNaziv!=null){
            dogadjaj.promeniNaziv(
                    request.getParameter("nazivDogadjaj"),
                    Integer.parseInt(request.getParameter("id")),
                    pocetak_vreme,
                    kraj_vreme
            );
            response.sendRedirect("http://localhost:8080/project_war/blagajnik");
            return;
        }

        //dodajUlaznicu
        //id,kategorija,cena,broj
        String dodajUlaznicu = request.getParameter("dodajUlaznicu");
        if(dodajUlaznicu!=null){
            String id = request.getParameter("id");
            String kategorija = request.getParameter("kategorija");
            String cena = request.getParameter("cena");
            String broj = request.getParameter("broj");

            new ulaznica(kategorija,Integer.parseInt(cena),Integer.parseInt(broj),Integer.parseInt(id)).dodaj();
            response.sendRedirect("http://localhost:8080/project_war/blagajnik");
            return;
        }

        //naziv,pocetak,vreme,kraj,opis
        //lokacija
        String naziv = request.getParameter("naziv");
        String pocetak = request.getParameter("pocetak");
        String vreme = request.getParameter("vreme");
        String kraj = request.getParameter("kraj");
        String opis = request.getParameter("opis");
        String mesto = ((korisnik)request.getSession().getAttribute("korisnik")).getAdresa();

        dogadjaj d = new dogadjaj(naziv,pocetak,vreme,kraj,mesto,opis);
        d.dodaj();
        response.sendRedirect("http://localhost:8080/project_war/blagajnik");
    }

    public void destroy() {
    }
}

