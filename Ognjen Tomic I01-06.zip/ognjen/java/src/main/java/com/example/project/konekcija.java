package com.example.project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class konekcija {
    static final String drajver = "com.mysql.jdbc.Driver";
    static final String url = "jdbc:mysql://localhost/karte";
    static final String username = "root";
    static final String password = "";

    public static Connection konektuj(){
        try {
            Class.forName(drajver);
            Connection conn = DriverManager.getConnection(url, username, password);
            return conn;
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            System.out.println(e);
            return null;
        }
    }
}
