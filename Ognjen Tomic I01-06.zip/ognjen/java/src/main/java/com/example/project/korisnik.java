package com.example.project;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class korisnik {
    private int id;
    private String ime;
    private String prezime;
    private String korime;
    private String lozinka;
    private String adresa;
    private String email;
    private String telefon;
    private String status;

    public korisnik(int id) {
        this.id = id;
    }

    public korisnik(int id, String ime, String prezime, String korime, String lozinka, String email, String adresa, String telefon, String status) {
        this.id = id;
        this.ime = ime;
        this.prezime = prezime;
        this.korime = korime;
        this.lozinka = lozinka;
        this.adresa = adresa;
        this.email = email;
        this.telefon = telefon;
        this.status=status;
    }

    public korisnik(String ime, String prezime, String korime, String lozinka, String email, String adresa, String telefon,String status) {
        this.ime = ime;
        this.prezime = prezime;
        this.korime = korime;
        this.lozinka = lozinka;
        this.adresa = adresa;
        this.email = email;
        this.telefon = telefon;
        this.status=status;
    }

    public korisnik(String blokirajKorisnika) {
        this.id= Integer.parseInt(blokirajKorisnika);
    }

    public int broj_blokiranih(int idd){
        String sql = "SELECT COUNT(*) AS broj FROM rezervacije WHERE status='blokirano' AND korisnik_id="+idd;

        Connection conn = konekcija.konektuj();
        Statement stmt = null;
        try {
            stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            rs.next();
            int broj = rs.getInt("broj");
            return broj;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            return 0;
        }
    }

    public static ArrayList<korisnik> vrati_korisnike(){
        ArrayList<korisnik> arr = new ArrayList<>();

        Connection conn = konekcija.konektuj();
        String sql = "SELECT * FROM korisnici";
        Statement stmt = null;
        try {
            stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()){
                korisnik k = new korisnik(
                        rs.getInt("id"),
                        rs.getString("ime"),
                        rs.getString("prezime"),
                        rs.getString("korime"),
                        rs.getString("lozinka"),
                        rs.getString("email"),
                        rs.getString("adresa"),
                        rs.getString("telefon"),
                        rs.getString("status")
                );
                arr.add(k);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            return arr;
        }
        return arr;
    }

    public static korisnik login(String korime,String lozinka){
        Connection conn = konekcija.konektuj();
        try {
            Statement stmt = conn.createStatement();
            String sql = "SELECT * FROM korisnici WHERE korime='"+korime+"' AND lozinka='"+lozinka+"' AND status!='none' AND status!='blokirano'";
            System.out.println(sql);
            ResultSet rs = stmt.executeQuery(sql);
            if(rs.next()){
                korisnik k = new korisnik(
                        rs.getInt("id"),
                        rs.getString("ime"),
                        rs.getString("prezime"),
                        rs.getString("korime"),
                        rs.getString("lozinka"),
                        rs.getString("email"),
                        rs.getString("adresa"),
                        rs.getString("telefon"),
                        rs.getString("status")
                );
                return k;
            }else{
                return null;
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            return null;
        }
    }

    public void odobri(){
        Connection conn = konekcija.konektuj();
        try {
            Statement st = conn.createStatement();
            String sql = "UPDATE korisnici SET status='korisnik' WHERE id="+this.id;
            st.executeUpdate(sql);
            conn.close();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public void blokiraj(){
        Connection conn = konekcija.konektuj();
        try {
            Statement st = conn.createStatement();
            String sql = "UPDATE korisnici SET status='blokirano' WHERE id="+this.id;
            st.executeUpdate(sql);
            conn.close();
            System.out.println("blokirano");
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public void obrisi(){
        Connection conn = konekcija.konektuj();
        try {
            Statement st = conn.createStatement();
            String sql = "DELETE FROM korisnici WHERE id="+this.id;
            st.executeUpdate(sql);
            conn.close();
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public boolean registruj(){
        Connection conn = konekcija.konektuj();
        if(conn==null){
            System.out.println("konekcija null");
            return false;
        }
        try {
            Statement st = conn.createStatement();
            String sql = "INSERT INTO korisnici VALUES(null,'"+this.ime+"','"+this.prezime+"','"+this.korime+"','"+this.lozinka+"','"+this.email+"','"+this.adresa+"','"+this.telefon+"','"+this.status+"')";
            st.executeUpdate(sql);
            conn.close();
            return true;
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            System.out.println(throwables);
            return false;
        }
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getIme() {
        return ime;
    }

    public void setIme(String ime) {
        this.ime = ime;
    }

    public String getPrezime() {
        return prezime;
    }

    public void setPrezime(String prezime) {
        this.prezime = prezime;
    }

    public String getKorime() {
        return korime;
    }

    public void setKorime(String korime) {
        this.korime = korime;
    }

    public String getLozinka() {
        return lozinka;
    }

    public void setLozinka(String lozinka) {
        this.lozinka = lozinka;
    }

    public String getAdresa() {
        return adresa;
    }

    public void setAdresa(String adresa) {
        this.adresa = adresa;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefon() {
        return telefon;
    }

    public void setTelefon(String telefon) {
        this.telefon = telefon;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "korisnik{" +
                "id=" + id +
                ", ime='" + ime + '\'' +
                ", prezime='" + prezime + '\'' +
                ", korime='" + korime + '\'' +
                ", lozinka='" + lozinka + '\'' +
                ", adresa='" + adresa + '\'' +
                ", email='" + email + '\'' +
                ", telefon='" + telefon + '\'' +
                '}';
    }
}
