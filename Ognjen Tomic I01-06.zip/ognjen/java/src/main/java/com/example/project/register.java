package com.example.project;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet(name = "register", value = "/register")
public class register extends HttpServlet {

    public void init() {

    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        HttpSession session = request.getSession();
        if(session.getAttribute("id") != null){
            request.setAttribute("poruka","vec ste ulogovani");
            response.setContentType("text/html");
            request.getRequestDispatcher("/index.jsp").forward(request, response);
        }

        response.setContentType("text/html");
        request.getRequestDispatcher("/register.jsp").forward(request, response);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String dogadjaj = "korisnik registracija";

        String ime = request.getParameter("ime");
        String prezime = request.getParameter("prezime");
        String korime = request.getParameter("korime");
        String lozinka = request.getParameter("lozinka");
        String potvrda = request.getParameter("potvrda");
        String email = request.getParameter("email");
        String adresa = request.getParameter("adresa");
        String telefon = request.getParameter("telefon");
        String status = request.getParameter("status");
        if(status==null){
            status="none";
        }else{
            dogadjaj = "admin registracija";
        }
        //provera da li susvi podacci uneti
        //provera duzine podataka
        //provera nedozvoljenih karaktera
        //email format
        //provera da li se lozinka i potvrda slazu

        if(dogadjaj.equals("admin registracija")){
            korisnik k = new korisnik(ime,prezime,korime,lozinka,email,adresa,telefon,status);
            if(k.registruj()){
                response.sendRedirect("http://localhost:8080/project_war/admin");
                return;
            }else{
                request.setAttribute("poruka","registracija neuspesna");
                doGet(request, response);
                return;
            }
        }

        if(!lozinka.equals(potvrda)){
            request.setAttribute("poruka","lozinka i potvrda se ne podudaraju");
            doGet(request, response);
            return;
        }
        //provera da li je korime vec upotrebljeno
        //provera da li je email vec upotrebljen

        korisnik k = new korisnik(ime,prezime,korime,lozinka,email,adresa,telefon,status);
        if(k.registruj()){
            request.setAttribute("poruka","registracija uspesna");
            doGet(request, response);
            return;
        }else{
            request.setAttribute("poruka","registracija neuspesna");
            doGet(request, response);
            return;
        }
    }

    public void destroy() {
    }
}
