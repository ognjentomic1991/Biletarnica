package com.example.project;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Date;
import java.util.concurrent.TimeUnit;

public class rezervacija {
    private int id;
    private int ulaznicaa;
    private int korisnik;
    private String datum;
    private String status;

    public rezervacija(int id) {
        this.id = id;
    }

    public rezervacija(int id, int ulaznicaa, int korisnik, String datum) {
        this.id = id;
        this.ulaznicaa = ulaznicaa;
        this.korisnik = korisnik;
        this.datum = datum;
    }

    public rezervacija(int ulaznica, int korisnik, String datum) {
        this.ulaznicaa = ulaznica;
        this.korisnik = korisnik;
        this.datum = datum;
    }

    public rezervacija(int id, int ulaznica_id, int korisnik_id, String datum, String status) {
        this.id=id;
        this.ulaznicaa=ulaznica_id;
        this.korisnik=korisnik_id;
        this.datum=datum;
        this.status=status;
    }



    public static ArrayList<rezervacija> getRezervisane(){
        ArrayList<rezervacija> arr = new ArrayList<>();

        Connection conn = konekcija.konektuj();
        String sql = "SELECT * FROM rezervacije WHERE status='rezervisano'";
        Statement stmt = null;
        try {
            stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()){
                rezervacija k = new rezervacija(
                        rs.getInt("id"),
                        rs.getInt("ulaznica_id"),
                        rs.getInt("korisnik_id"),
                        rs.getString("datum"),
                        rs.getString("status")
                );
                arr.add(k);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            return arr;
        }
        return arr;
    }

    public static ArrayList<rezervacija> getAll(int id_kor){
        ArrayList<rezervacija> arr = new ArrayList<>();

        Connection conn = konekcija.konektuj();
        String sql = "SELECT * FROM rezervacije WHERE korisnik_id="+id_kor;
        Statement stmt = null;
        try {
            stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);
            while (rs.next()){
                rezervacija k = new rezervacija(
                        rs.getInt("id"),
                        rs.getInt("ulaznica_id"),
                        rs.getInt("korisnik_id"),
                        rs.getString("datum"),
                        rs.getString("status")
                );
                arr.add(k);
            }
        } catch (SQLException throwables) {
            throwables.printStackTrace();
            return arr;
        }
        return arr;
    }

    public int proslo_dana() throws ParseException {
        Date datum = new SimpleDateFormat("yyyy-MM-dd").parse(this.datum);
        Date trenutni = new Date();

        long diff = trenutni.getTime()- datum.getTime();
        int d = (int) TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);

        System.out.println("dan=>"+d);

        return d;
    }

    public boolean proslo_2_dana() throws ParseException {
        Date datum = new SimpleDateFormat("yyyy-MM-dd").parse(this.datum);
        Date trenutni = new Date();

        long diff = trenutni.getTime()- datum.getTime();
        int d = (int) TimeUnit.DAYS.convert(diff, TimeUnit.MILLISECONDS);

        System.out.println("dan=>"+d);

        if (d>2) {
            return true;
        }
        return false;
    }

    public void prodaj(){
        Connection conn = konekcija.konektuj();
        try {
            Statement st = conn.createStatement();
            String sql = "UPDATE rezervacije SET status='prodato' WHERE id="+this.id;
            st.executeUpdate(sql);
            conn.close();
            ulaznica.prodaj(ulaznicaa);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public void blokiraj(){
        Connection conn = konekcija.konektuj();
        try {
            Statement st = conn.createStatement();
            String sql = "UPDATE rezervacije SET status='blokirano' WHERE id="+this.id;
            st.executeUpdate(sql);
            conn.close();
            ulaznica.prodaj(ulaznicaa);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public void otkazi(){
        Connection conn = konekcija.konektuj();
        try {
            Statement st = conn.createStatement();
            String sql = "DELETE FROM rezervacije WHERE id="+this.id;
            st.executeUpdate(sql);
            conn.close();
            ulaznica.prodaj(ulaznicaa);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public void rezervisi(){
        Connection conn = konekcija.konektuj();
        try {
            Statement st = conn.createStatement();
            String sql = "INSERT INTO rezervacije VALUES(null,"+ulaznicaa+","+korisnik+",'"+datum+"','rezervisano')";
            st.executeUpdate(sql);
            conn.close();
            ulaznica.prodaj(ulaznicaa);
        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getUlaznicaa() {
        return ulaznicaa;
    }

    public void setUlaznicaa(int ulaznicaa) {
        this.ulaznicaa = ulaznicaa;
    }

    public int getKorisnik() {
        return korisnik;
    }

    public void setKorisnik(int korisnik) {
        this.korisnik = korisnik;
    }

    public String getDatum() {
        return datum;
    }

    public void setDatum(String datum) {
        this.datum = datum;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
