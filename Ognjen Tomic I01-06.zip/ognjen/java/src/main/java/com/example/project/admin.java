package com.example.project;

import java.io.*;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

@WebServlet(name = "admin", value = "/admin")
public class admin extends HttpServlet {

    public void init() {

    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        HttpSession session = request.getSession();
        if(session.getAttribute("id") == null){
            request.setAttribute("poruka","niste ulogovani");
            response.setContentType("text/html");
            request.getRequestDispatcher("/index.jsp").forward(request, response);
        }else{
            korisnik k = (korisnik) session.getAttribute("korisnik");
            if(k.getStatus().equals("admin")){
                request.setAttribute("admin",k);
                request.setAttribute("korisnici",korisnik.vrati_korisnike());
                response.setContentType("text/html");
                request.getRequestDispatcher("/admin.jsp").forward(request, response);
            }else{
                request.setAttribute("poruka","samo administrator ima pristup ovoj stranici");
                response.setContentType("text/html");
                request.getRequestDispatcher("/index.jsp").forward(request, response);
            }
        }

        response.setContentType("text/html");
        request.getRequestDispatcher("/index.jsp").forward(request, response);
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        //blokirajKorisnika
        String blokirajKorisnika = request.getParameter("blokirajKorisnika");
        if(blokirajKorisnika!=null){
            new korisnik(blokirajKorisnika).blokiraj();
            response.sendRedirect("http://localhost:8080/project_war/admin");
        }

        String id = request.getParameter("id");
        String status = request.getParameter("status");

        if(status.equals("odobri")){
            new korisnik(Integer.parseInt(id)).odobri();
        }

        if(status.equals("obrisi")){
            new korisnik(Integer.parseInt(id)).obrisi();
        }

        response.sendRedirect("http://localhost:8080/project_war/admin");
    }

    public void destroy() {
    }
}

