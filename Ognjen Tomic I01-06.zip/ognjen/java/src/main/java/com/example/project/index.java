package com.example.project;

import java.io.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import javax.servlet.annotation.*;

@WebServlet(name = "index", value = "/index")
public class index extends HttpServlet {

    public void init() {

    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {



            //neulogovan
            ArrayList<dogadjaj> arr2 = new ArrayList<dogadjaj>();
            ArrayList<dogadjaj> arr = dogadjaj.pretrazi("","");
            if(request.getParameter("pages")!=null){
                int pages = Integer.parseInt(request.getParameter("pages"));
                System.out.println("pages="+pages);
                for(int i=(pages-1)*10;i<Math.min(pages*10+10,arr.size());i++){
                    arr2.add(arr.get(i));
                }
            }else{
                for(int i=0;i<Math.min(10,arr.size());i++){
                    arr2.add(arr.get(i));
                }
            }
            double n = Math.ceil(arr.size()/10)+1;
            System.out.println(n);
            request.setAttribute("pagesnum",n);
            request.setAttribute("dogadjaji",arr2);
            request.getRequestDispatcher("/index.jsp").forward(request, response);
            return;



    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException, ServletException {
        //[rezervisi],id(d),ulaznica(id)
        HttpSession session = request.getSession();
        korisnik k = (korisnik)session.getAttribute("korisnik");
        if(request.getParameter("rezervisi")!=null){
            int ulaznica = Integer.parseInt(request.getParameter("ulaznica"));
            int korisnik = k.getId();
            Date date = new Date();
            SimpleDateFormat formatter = new SimpleDateFormat("YYYY/MM/dd");
            String datum = formatter.format(date);
            new rezervacija(ulaznica,korisnik,datum).rezervisi();
            doGet(request,response);
        }
    }

    public void destroy() {
    }
}

